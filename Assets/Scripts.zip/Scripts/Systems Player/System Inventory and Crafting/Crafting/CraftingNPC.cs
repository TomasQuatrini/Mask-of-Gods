using System.Collections.Generic;
using UnityEngine;

public class CraftingNPC : MonoBehaviour, IInteractable
{
    [SerializeField] private HUD_CraftingUI _craftingUI;
    [SerializeField] private List<string> _recipePaths = new List<string>();
    private List<Recipe> _availableRecipes = new List<Recipe>();

    public void Awake()
    {
        LoadRecipes();
    }

    public void Interact(IContext context)
    {
        if (context is PlayerContext playerContext)
        {
            _craftingUI.Open(playerContext, _availableRecipes);
        }
    }

    private void LoadRecipes()
    {
        _availableRecipes = new List<Recipe>();
        foreach (var path in _recipePaths)
        {
            var recipe = UnityEngine.Resources.Load<Recipe>(path);
            if (recipe != null)
            {
                _availableRecipes.Add(recipe);
            }
            else
            {
                Debug.LogWarning($"CraftingNPC: Failed to load recipe at path: {path}");
            }
        }
    }
}
