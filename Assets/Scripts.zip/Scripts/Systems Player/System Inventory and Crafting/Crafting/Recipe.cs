using UnityEngine;
using System.Inventory;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "New Recipe", menuName = "Crafting/Recipe")]

[System.Serializable]
public class Recipe : ScriptableObject
{
    [SerializeField] private string _recipeName;
    [SerializeField] private List<ItemStack> ingredients = new();
    [SerializeField] private ItemStack result = new ItemStack();

    public string RecipeName => string.IsNullOrWhiteSpace(_recipeName) ? "Sin Nombre" : _recipeName;
    public IReadOnlyList<ItemStack> Ingredients => ingredients;
    public ItemStack Result => result;

    private void OnValidate()
    {
        ingredients ??= new List<ItemStack>();
        result ??= new ItemStack(null, 1);

        ingredients.RemoveAll(i => i == null);

        foreach (var ingredient in ingredients)
        {
            if (ingredient.quantity < 1)
                ingredient.quantity = 1;
        }

        if (result.quantity < 1)
            result.quantity = 1;
    }
}