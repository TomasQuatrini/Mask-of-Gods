﻿using UnityEngine;
using Fusion;

public class NetPlayerResources : NetworkBehaviour
{
    private PlayerContext _ctx;
    private PlayerHealth _healthResource;
    private PlayerStaminaSM _staminaResource;

    [Header("Máximos (solo para UI)")]
    private float _maxHealth = 100f;
    private float _maxStamina = 100f;

    // Estos son los valores que se replican en red
    [Networked] public float NetHealth { get; private set; }
    [Networked] public float NetStamina { get; private set; }

    // Por si querés enganchar algo de UI por evento (opcional)
    public System.Action<float, float> OnResourcesChanged;

    public float MaxHealth => _maxHealth;
    public float MaxStamina => _maxStamina;

    public override void Spawned()
    {
        _ctx = GetComponentInParent<PlayerContext>();
        if (_ctx == null)
        {
            Debug.LogError("[NetPlayerResources] No encontré PlayerContext");
            return;
        }

        _healthResource = _ctx.Health;
        _staminaResource = _ctx.Stamina;

        if (_healthResource == null || _staminaResource == null)
        {
            Debug.LogError("[NetPlayerResources] Faltan PlayerHealth o PlayerStaminaSM");
            return;
        }

        // El dueño del input manda el valor inicial al server
        if (Object.HasInputAuthority)
        {
            Rpc_UpdateVitals(
                _healthResource.CurrentHealth,
                _staminaResource.StaminaResource.Current
            );
        }
        _maxHealth = _healthResource.MaxHealth;
        _maxStamina = _staminaResource.StaminaResource.Max;            
    }

    public override void FixedUpdateNetwork()
    {
        // Solo el dueño del input avisa al server
        if (!Object.HasInputAuthority)
            return;

        if (_healthResource == null || _staminaResource == null)
            return;

        float h = _healthResource.CurrentHealth;
        float s = _staminaResource.StaminaResource.Current;

        // Si quisieras, podés chequear si cambió lo suficiente antes de mandar
        Rpc_UpdateVitals(h, s);
    }

    // CLIENT (InputAuthority) → SERVER (StateAuthority)
    [Rpc(RpcSources.InputAuthority, RpcTargets.StateAuthority)]
    private void Rpc_UpdateVitals(float health, float stamina, RpcInfo info = default)
    {
        NetHealth = health;
        NetStamina = stamina;

        // Si querés que también el server tenga barra de ese jugador
        OnResourcesChanged?.Invoke(NetHealth, NetStamina);
    }

    // Esta se ejecuta en TODOS los peers cada frame visual
    public override void Render()
    {
        // Acá simplemente avisamos a la UI (host y clientes)
        OnResourcesChanged?.Invoke(NetHealth, NetStamina);
    }
}