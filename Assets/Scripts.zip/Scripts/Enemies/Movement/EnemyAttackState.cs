using UnityEngine;

public class EnemyAttackState : IEnemyMovementState
{
    private readonly EnemyContext _ctx;
    private readonly EnemyMovementSM _sm;

    private const float LoseSightExtra = 2f; // hist�resis para no cambiar de estado todo el tiempo

    public EnemyAttackState(EnemyContext ctx, EnemyMovementSM sm)
    {
        _ctx = ctx;
        _sm = sm;
    }

    public void Enter()
    {
        if (_ctx.Target == null)
        {
            // Si por alg�n motivo no tiene player, vuelve a patrulla
            _sm.ToPatrol();
            return;
        }

        _ctx.Agent.isStopped = false;
        // Animaci�n de correr / atacar
    }

    public void Tick()
    {
        if (_ctx.Target == null)
        {
            _sm.ToPatrol();
            return;
        }

        float dist = _ctx.DistanceToTarget();

        // Si el player se fue demasiado lejos, volver a patrulla
        if (dist > _ctx.DetectionRadius + LoseSightExtra)
        {
            _sm.ToPatrol();
            return;
        }

        // Si est� dentro del rango de ataque > aqu� ir�a tu l�gica de pegar/disparar
        if (_ctx.IsTargetWithinAttackRange())
        {
            _ctx.Agent.isStopped = true;

            // Rotar hacia el jugador
            Vector3 dir = _ctx.Target.position - _ctx.Transform.position;
            dir.y = 0f;
            if (dir.sqrMagnitude > 0.001f)
            {
                Quaternion targetRot = Quaternion.LookRotation(dir);
                _ctx.Transform.rotation = Quaternion.Slerp(
                    _ctx.Transform.rotation,
                    targetRot,
                    10f * Time.deltaTime
                );
            }
            _ctx.ComponentAttack.Attack();
        }
        else
        {
            // Todav�a no est� en rango: seguir persiguiendo
            _ctx.Agent.isStopped = false;
            _ctx.Agent.SetDestination(_ctx.Target.position);
        }
    }

    public void Exit()
    {
        _ctx.Agent.isStopped = false;
    }
}