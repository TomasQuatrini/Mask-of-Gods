using UnityEngine;

public class PlayerCameraBinder : MonoBehaviour
{
    private PlayerContext _ctx;

    private void Awake()
    {
        _ctx = GetComponentInParent<PlayerContext>();
    }

    private void Start()
    {
        if (_ctx == null)
        {
            Debug.LogError("PlayerCameraBinder no encontr� PlayerContext en los padres!");
            enabled = false;
            return;
        }
        if (CameraFollow.Instance == null)
        {
            Debug.LogError("Camera no est� inicializado!");
            enabled = false;
            return;
        }
        CameraFollow.Instance.SetTarget(_ctx.transform);
    }
}
