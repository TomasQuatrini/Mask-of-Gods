using UnityEngine;
using Fusion;
using System.Inventory;

public class NetItemConsume : NetworkBehaviour
{
    private PlayerContext _ctx;
    private PlayerInventoryComponent _inventory;
    private PlayerHealth _health;
    private PlayerStaminaSM _stamina;
    [SerializeField] private ItemDataBase _itemDataBase;

    [SerializeField] private ItemData _potionStamina;
    [SerializeField] private ItemData _potionHealth;

    public override void Spawned()
    {
        _ctx = GetComponentInParent<PlayerContext>();
        if (_ctx == null)
        {
            Debug.LogError("[NetItemConsume] No encontr� PlayerContext");
            return;
        }

        _inventory = _ctx.Inventory;
        _health = _ctx.Health;
        _stamina = _ctx.Stamina;           
    }

    public override void FixedUpdateNetwork()
    {
        if (GetInput<PlayerNetworkInput>(out var inputPlayer))
        {
            if (inputPlayer.ConsumeHealth)
            {
                Rpc_RequestConsume(_potionHealth.Id);
            }
            if (inputPlayer.ConsumeStamina)
            {
                Rpc_RequestConsume(_potionStamina.Id);
            }
        }
    }

    public void TryConsumeHealthPotion(ItemData healthPotion)
    {
        if (!Object.HasInputAuthority) return;
        if (healthPotion == null) return;

        Rpc_RequestConsume(healthPotion.Id);
    }

    public void TryConsumeStaminaPotion(ItemData staminaPotion)
    {
        if (!HasInputAuthority) return;
        if (staminaPotion == null) return;

        Rpc_RequestConsume(staminaPotion.Id);
    }

    [Rpc(RpcSources.InputAuthority, RpcTargets.StateAuthority)]
    private void Rpc_RequestConsume(string itemId, RpcInfo info = default)
    {
        if (!HasStateAuthority) return;
        if (string.IsNullOrEmpty(itemId)) return;

        EnsureRefs();
        if (_inventory == null) return;
        
        var db = _itemDataBase; 
        var itemData = db.GetItemById(itemId);
        if (itemData == null)
        {
            return;
        }
        bool consumed = _inventory.ConsumeItem(itemData);
        if (!consumed)
        {
            return;
        }
        ApplyItemEffect(itemData);
    }
    private void EnsureRefs()
    {
        if (_ctx == null)
            _ctx = GetComponentInParent<PlayerContext>();

        if (_ctx != null)
        {
            if (_inventory == null) _inventory = _ctx.Inventory;
            if (_health == null) _health = _ctx.Health;
            if (_stamina == null) _stamina = _ctx.Stamina;
        }
    }

    private void ApplyItemEffect(ItemData itemData)
    {
        // Si ten�s subclasses tipo ConsumableItemData, pod�s castear:
        if (itemData is ConsumableItemData consumable)
        {
            switch (consumable.Type_Consumable)
            {
                case ConsumableType.Health:
                    _health.Heal(consumable.Amount);
                    break;
                case ConsumableType.Stamina:
                    _stamina.StaminaResource.Increase(consumable.Amount);
                    break;
            }
        }
    }
}